const mongoose = require('mongoose');

const pointSchema = new mongoose.Schema({
    coordinates: {
        type: [Number],
        required: true,
    },
    },
    {
        timestamps: true
    });

const Point = mongoose.model('Point', pointSchema);

module.exports = Point;
