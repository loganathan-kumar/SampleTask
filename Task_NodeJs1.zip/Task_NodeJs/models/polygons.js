const mongoose = require('mongoose');

const polygonSchema = new mongoose.Schema({
    coordinates: {
        type: [Number],
        required: true,
    },
},
    {
        timestamps: true
    });

const Polygon = mongoose.model('Polygon', polygonSchema);

module.exports = Polygon;
