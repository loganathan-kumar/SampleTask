require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Point = require('./models/points');
const Polygon = require('./models/polygons');


const app = express();
const PORT = process.env.PORT

app.use(bodyParser.json())

mongoose.connect(process.env.DB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

app.post('/api/points', async (req, res) => {
    try {
        const point = new Point(req.body);
        console.log(point, 'point')
        await point.save();
        res.status(201).send({ message: `Successfully created Points`, data: point });
    } catch (error) {
        res.status(500).send(error);
    }
});

app.patch('/api/points/update/:id', async (req, res) => {
    try {
        const filter = req.params.id
        const update = await Point.findByIdAndUpdate(filter, { $set: req.body }, { new: true })
        console.log(update)
        if (!update) {
            throw new Error('Points not found')
        }
        res.status(201).send({ message: `Successfully updated Ponits`, data: update });
        return {
            status: 200,
            body: update,
        }
    } catch (error) {
        res.status(500).send(error)
    }
})

app.get('/api/points', async (req, res) => {
    try {
        const points = await Point.find();
        console.log(points, 'points')
        res.status(200).send({message: `Successfully get the data`, data: points});
    } catch (error) {
        res.status(500).send(error);
    }
});


app.post('/api/polygons', async (req, res) => {
    try {
        console.log(req.body)
        const polygon = new Polygon(req.body);
        await polygon.save();
        res.status(201).send({message: `Successfully created Polygons`, data: polygon});
    } catch (error) {
        res.status(500).send(error);
    }
});

app.get('/api/polygons', async (req, res) => {
    try {
        const polygons = await Polygon.find();
        res.status(200).send({message: `Successfully get the data`, data: polygons});
    } catch (error) {
        res.status(500).send(error);
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});